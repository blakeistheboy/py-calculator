from customtkinter import *


def calculate():
    #variables
    value = dropdown.get()
    first_num = int(first.get())
    second_num = int(second.get())


    if value == 'addition':

        final = first_num + second_num
        output.configure(text=f'answer: {final}')

    elif value == 'subtraction':

        final = first_num - second_num
        output.configure(text=f'answer: {final}')
        
    elif value == 'multiplication':

        final = first_num * second_num
        output.configure(text=f'answer: {final}')
    
    elif value == 'division':

        final = first_num / second_num
        output.configure(text=f'answer: {final}')


#setup
calc = CTk()
calc.title('Calculator')
calc.geometry('500x500')
set_appearance_mode('System')
set_default_color_theme('themes/coffee.json')

#variables
d_font = CTkFont('Times New Roman', 15, 'bold')

#frames
frame = CTkFrame(calc, width=300, height=30)
frame.pack(padx=10, pady=10)

frame2 = CTkFrame(calc, width=200, height=30)
frame2.pack(padx=10, pady=10)

frame3 = CTkFrame(calc, width=200, height=30)
frame3.pack(padx=10, pady=10)


#output
output = CTkLabel(frame, text='TYPE EQUATION TO BEGIN', font=d_font, width=300, height=30)
output.grid(row = 0)

#first
first = CTkEntry(frame2, placeholder_text='First integer', font=d_font)
first.pack(pady=10, padx=10)

#second
second = CTkEntry(frame2, placeholder_text='Second integer', font=d_font)
second.pack(pady=10, padx=10)

#option pad
dropdown = CTkOptionMenu(frame3, width=200, height=30, values=[
    'addition',
    'subtraction',
    'multiplication',
    'division'
], font=d_font)
dropdown.pack(pady=10, padx=10)

#calculate
button = CTkButton(calc, width=100, height=20, text='calculate problem', command=calculate, font=d_font)
button.pack(pady=2, padx=10)


calc.mainloop()


